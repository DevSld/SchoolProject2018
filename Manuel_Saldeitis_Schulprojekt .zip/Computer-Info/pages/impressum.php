<div class="ueberschrift">
	Hier finden Sie einige Informatinen ueber den Betreiber der Webseite
</div>
<!-- Impressum Infos -->
<div class="info">
	Computer-Shop GmbH<br/>
	Vertretungsberechtigte Person:<br/> Manuel Saldeitis<br/>
	Anschrift:<br/> Marquardtsweg 39a<br/> 21217 Seevetal<br/>
	Tel: <br/>041054516<br/>
	Email: <br/>manuel.saldeitis@web.de<br/>
</div>
