<div class="ueberschrift">
	Wählen Sie zwischen den Grafikkarten
</div>
<div class="text">
	Klicke, um eine Grafikkarte auszuwählen.
</div>
<!-- image map -->
<!--	
	<center>
	<img src="bilder/imagemapgrafik.jpg" width="978" height="732" alt="Grafikkarten"
			usemap="Grafikkarten">
		<map name="Grafikkarten">
			<area	shape="rect" coords="159,300,678,50"
					href="?page=gtx460"
					title="EVGA Geforce GTX 460">
			<area	shape="rect" coords="150,650,900,350"
					href="?page=gtx770"
					title="Zotac Geforce GTX 770 AMP! Edition">	
		</map>
	-->
	<center>
	<a href="?page=gtx460"> 
		<img src="bilder/gtx460.jpg" width="400" height="200" alt="Grafikkarten"> 
	</a>
	<br>
	<a href="?page=gtx770"> 
		<img src="bilder/gtx770.jpg" width="400" height="200" alt="Grafikkarten"> 
	</a>		
	</center>

<!--Sollten die Image Maps nicht funktionieren benutzen Sie bitte den Chrome-Browser.-->
