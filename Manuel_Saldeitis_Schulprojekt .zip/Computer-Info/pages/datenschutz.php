<div class="ueberschrift">
	Hier finden Sie heraus, wie Ihre Daten weiterverarbeitet werden.
</div>
<div class="info">
	Es werden keinerlei Daten weitergegeben.<br>
	Die durch das Feedback entstandene Text Datei kann Manuell gelöscht werden.
</div>