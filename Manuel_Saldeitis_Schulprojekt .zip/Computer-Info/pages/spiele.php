<div class="ueberschrift">
	Wählen Sie ein Spiel aus.
</div>
<div class="text">	
	Klicke, um ein Spiel auszusuchen.
</div>
<!-- image map -->
<!--
	<center>
		<img src="bilder/imagemapgames.jpg" width="488" height="652" alt="Spiele"
				usemap="Spiele">
			<map name="Spiele">
				<area	shape="rect" coords="20,300,240,4"
						href="?page=starcraft2"
						title="Starcraft 2">
				<area	shape="rect" coords="233,293,446,7"
						href="?page=overwatch"
						title="Overwatch">
				<area	shape="rect" coords="11,610,223,306"
						href="?page=rainbow"
						title="Rainbow Six Siege">
				<area	shape="rect" coords="234,625,448,311"
						href="?page=splintercell"
						title="Splinter Cell Blacklist">		
	
		</map>
-->
<center>
<a href="?page=starcraft2"> 
	<img src="bilder/sc2.jpg" width="300" height="400" alt="Spiele"> 
</a>
<br>
<a href="?page=overwatch"> 
	<img src="bilder/overwatch.jpg" width="300" height="400" alt="Spiele"> 
</a>		
</center>
	


<!--Sollten die Image Maps nicht funktionieren benutzen Sie bitte den Chrome-Browser.-->