<div class="ueberschrift">
	Dies ist eine Geforce GTX 770 AMP von Zotac.
</div>
<div>
	<center>
		Der Hersteller dieser Grafikkarte ist NVIDIA
	</center>
</div>
<div class="inform">
	<table>
		<tr>	<td>Core Clock Speed</td><td>1150MHz</td>	</tr>
		<tr>	<td>Processing Cores</td><td>1536</td>	</tr>
		<tr>	<td>Memory Clock Speed</td><td>7200MHz</td>	</tr>
		<tr>	<td>Memory Bandwidth</td><td>256GB/sec</td>	</tr>
		<tr>	<td>Shader Clock Speed</td><td>1440MHz</td>	</tr>
		<tr>	<td>Bus	PCI-E</td><td>2.0</td>	</tr>
		<tr>	<td>Interface</td><td>DisplayPort 1.2,HDMI 2.0, 2x DL-DVI </td>	</tr>
		<tr>	<td></td><td></td><tr>	</tr>
	</table>
	<img src="bilder/gtx770.jpg" height="200" width="400">
</div>
	<!--zurück funnktion-->
<a href="?page=grafikkarten"">
	<input type="submit" value="Zurück" class="zurueckbutton">
</a>
