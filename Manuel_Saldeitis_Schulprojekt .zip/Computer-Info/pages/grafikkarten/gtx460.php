<div class="ueberschrift">
	Dies ist eine Geforce GTX 460 von EVGA.
</div>

<div>
<	center>
		Der Hersteller dieser Grafikkarte ist NVIDIA
	</center>
</div>
<div class="inform">
	<table>
		<tr>	<td>Core Clock Speed</td><td>720MHz</td>	</tr>
		<tr>	<td>Processing Cores</td><td>336</td>	</tr>
		<tr>	<td>Memory Clock Speed</td><td>3600MHz</td>	</tr>
		<tr>	<td>Memory Bandwidth</td><td>115.2GB/sec</td>	</tr>
		<tr>	<td>Shader Clock Speed</td><td>1440MHz</td>	</tr>
		<tr>	<td>Bus	PCI-E</td><td>2.0</td>	</tr>
		<tr>	<td>Interface</td><td><DVI-I, DVI-I, Mini-HDMI/td>	</tr>
	</table>
	<img src="bilder/gtx460.jpg" height="200" width="400">
</div>

	<!--zurück funnktion-->
	
<a href="?page=grafikkarten"">
	<input type="submit" value="Zurück" class="zurueckbutton">
</a>
