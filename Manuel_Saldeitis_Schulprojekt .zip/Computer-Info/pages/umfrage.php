<div class="ueberschrift">
	Wie finden Sie diese Seite?
</div>

<!-- umfrage/feedback -->
<div class="info">
  <form action="?page=umfrage_email" method="post" enctype="text/plain ">
		<!-- Lege Variablen fest -->
			Name:<br>
		<input type="text" name="name"><br>
			Betreff:<br>
		<input type="text" name="betreff"><br>
			E-mail:<br>
		<input type="text" name="mail"><br>
			Comment:<br>
		<input type="text" name="Nachricht" size="30"><br><br>
		
		<!-- Variablen werden übergeben -->
		<input type="submit" value="Send">
		<input type="reset" value="Reset">
	</form>
</div>