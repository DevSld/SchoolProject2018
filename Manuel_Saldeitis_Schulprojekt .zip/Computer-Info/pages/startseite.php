<div>
	<div class="ueberschrift">
		Wilkommen bei Computer-Info
	</div>
</div>	
<div class="info">
	Das Ziel dieser Webseite ist es, eine Informationsquelle über Grafikkarten und Spiele zu bieten.<br/>
	Hier werden Sie einige Informationen zu ausgewählten Artikeln sehen, welche Sie für das Quiz benötigen werden.
	
	
	
<!--Sollten die Image Maps nicht funktionieren benutzen Sie bitte den Chrome-Browser.-->
<!--	Um die Feedback Funktion nutzen zu können gehen Sie bitte zuerst in den Ordner Pfad /Xampp/php .
	Sichern Sie die vorhandene php.ini Datei zuerst in einem Verzeichnis, in dem Sie diese wiederfinden.
	Kopieren Sie die php.ini -Datei aus dem  /Computer-Info/php Ordner in das /Xampp/php Verzeichnis.
	Wenn Sie Nun die Feedback Funktion nutzen, wird eine Textdatei mit der Nachricht, dem Absender und dem Empfänger im Verzeichnis /Xampp/mailoutput erstellt.
-->	
</div>