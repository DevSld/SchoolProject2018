<div class="ueberschrift">
	Starcraft 2
</div>

	Rainbow Six Siege ist ein Online Mehrspieler Shooter 
	<p>Das Spiel kostet 19,99€</p>
<div class="inform">
	<p class="anforderung">Mindestvorraussetzungen</p>
		OS 	Win Xp 32 <br/>
		CPU 	Pentium 4 2.66GHz / Athlon XP 2500+<br/>
		RAM 	1 GB<br/>
		GPU 	Radeon HD 3300 / Radeon HD 3300<br/>
		HDD 	12 GB<br/>
	<p class="anforderung">	Empfohlene Systemvorraussetzungen</p>
		OS 	Win Vista 32<br/>
		CPU 	Pentium Dual Core E2220 2.40GHz / Phenom 8250e Triple-Core<br/>
		RAM 	2 GB<br/>
		GPU 	GeForce 8800 GTX 768MB / Radeon HD 3870<br/>
		HDD 	12 GB<br/>

<img src="bilder/sc2.jpg" class="spielebilder">
</div>
<a href="?page=spiele""><input type="submit" value="Zurück" class="zurueckbutton">
