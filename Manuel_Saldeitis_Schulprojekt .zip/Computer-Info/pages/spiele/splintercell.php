<div class="ueberschrift">
	Splinter Cell Blacklist
</div>

Rainbow Six Siege ist ein Online Mehrspieler Shooter 
	<p>Das Spiel kostet 19,99€</p>
<div class="inform">
	<p class="anforderung">Mindestvorraussetzungen</p>
		OS 	Win Xp 32<br/>
		CPU 	Core 2 Duo E6400 2.13GHz / Athlon 64 X2 Dual Core 5600+<br/>
		RAM 	2 GB<br/>
		GPU 	GeForce 8800 GT / Radeon HD 3870<br/>
		HDD 	12 GB<br/>
	<p class="anforderung">	Empfohlene Systemvorraussetzungen</p>
		OS 	Win 7 64<br/>
		CPU 	Core 2 Quad Q6400 2.13GHz / Phenom 9550 Quad-Core<br/>
		RAM 	4 GB<br/>
		GPU 	GeForce GTX 260 / Radeon HD 5770 512MB<br/>
		HDD 	12 GB<br/>

<img src="bilder/splinter.jpg" class="spielebilder">
</div>
<a href="?page=spiele""><input type="submit" value="Zurück" class="zurueckbutton">