<div class="ueberschrift">
	Rainbow Six Siege
</div>
	Rainbow Six Siege ist ein Online Mehrspieler Shooter 
	<p>Das Spiel kostet 19,99€</p>
<div class="inform">
	<p class="anforderung">Mindestvorraussetzungen</p>
		OS 	Win 7 64 <br/>
		CPU 	Core i3-540 3.06GHz / Phenom II X3 720<br/>
		RAM 	4 GB<br/>
		GPU 	GeForce GTX 460 / Radeon HD 4850<br/>
		HDD 	5 GB<br/>
	<p class="anforderung">	Empfohlene Systemvorraussetzungen</p>
		OS 	Win 7 64<br/>
		CPU 	Core i5-670 3.46GHz / Phenom II X4 900e<br/>
		RAM 	6 GB<br/>
		GPU 	GeForce GTX 660 / Radeon HD 7950<br/>
		HDD 	5 GB<br/>

<img src="bilder/rainbow.jpg" class="spielebilder">
</div>
<a href="?page=spiele""><input type="submit" value="Zurück" class="zurueckbutton">